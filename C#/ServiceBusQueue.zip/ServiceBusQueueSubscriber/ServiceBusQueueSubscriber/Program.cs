﻿using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.ServiceBus.Core;
using System;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ServiceBusQueueSubscriber
{
    class Program
    {
        static string connectionString = "Endpoint=sb://sonusb.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=3t4TneJnljVN2JY2nOtr45ZCBanYJM0/YL85j9MXanI=";
        static string queueName = "items";
        static MessageReceiver receiver;

        static async Task Main(string[] args)
        {

            await ReceiveMessagesAsync(connectionString, queueName);
            Console.WriteLine("Press ENTER to Exit");
            Console.ReadLine();
        }

        static async Task ReceiveMessagesAsync(string connectionString, string queueName)
        {
            receiver = new MessageReceiver(connectionString, queueName, ReceiveMode.PeekLock);

            // register the RegisterMessageHandler callback
            receiver.RegisterMessageHandler( HandleMessage ,
                new MessageHandlerOptions(HandleError) 
                { 
                    AutoComplete = false, 
                    MaxConcurrentCalls = 1 
                });

            await Task.CompletedTask;
        }

        private static async Task HandleMessage(Message message,CancellationToken cancellationToken)
        {
            var body = message.Body;
            string messageText = Encoding.UTF8.GetString(body);
            Console.WriteLine("Message received: ");
            Console.WriteLine(messageText);
            Console.WriteLine("-------------------------------------------------------------------------");
            await receiver.CompleteAsync(message.SystemProperties.LockToken);

        }

        private static Task HandleError(ExceptionReceivedEventArgs e)
        {
            Console.WriteLine($"Exception: \"{e.Exception.Message}\" {e.ExceptionReceivedContext.EntityPath}");
            return Task.CompletedTask;
        }

    }
}
