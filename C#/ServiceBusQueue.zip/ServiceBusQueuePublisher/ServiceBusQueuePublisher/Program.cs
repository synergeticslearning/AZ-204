﻿using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.ServiceBus.Core;
using System;
using System.Text;
using System.Threading.Tasks;

namespace ServiceBusQueuePublisher
{
    class Program
    {
        

        static string connectionString = "Endpoint=sb://sonusb.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=3t4TneJnljVN2JY2nOtr45ZCBanYJM0/YL85j9MXanI=";
        static string queueName = "items";


        static async Task Main(string[] args)
        {
            await SendMessagesAsync(connectionString, queueName);
        }


        static async Task SendMessagesAsync(string connectionString, string queueName)
        {
            var sender = new MessageSender(connectionString, queueName);
            var ch = "Y";
            do
            {
                Console.WriteLine("Type your message:");
                string msgText = Console.ReadLine();
                var message = new Message(Encoding.UTF8.GetBytes(msgText))
                {
                    ContentType = "text/plain",
                    MessageId = Guid.NewGuid().ToString()
                };
                await sender.SendAsync(message);
                Console.WriteLine("Message send successfully");
                Console.WriteLine("Do you want to send more messages? (Y/N)");
                ch = Console.ReadLine();
            } while (ch == "Y");
        }       
    }
}
