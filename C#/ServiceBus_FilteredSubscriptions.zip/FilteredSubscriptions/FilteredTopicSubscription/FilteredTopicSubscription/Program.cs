﻿using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.ServiceBus.Management;
using Newtonsoft.Json;
using System;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace FilteredTopicSubscription
{
    class Program
    {
        const string ServiceBusConnectionString = "Endpoint=sb://sonusb.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=+p8wA0+QFZnwY/L3v3NGVbZ0sM1SDRpBqAyN3rbVab0=";
        const string TopicName = "orders";
        static ISubscriptionClient subscriptionClient;
        const string CorrelationIdToFilter = "4";

        static void Main(string[] args)
        {
            MainAsync().GetAwaiter().GetResult();
        }

        private static async Task MainAsync()
        {
            
            subscriptionClient = new SubscriptionClient(ServiceBusConnectionString, TopicName, "Online");
            var messageHandlerOptions = new MessageHandlerOptions(ExceptionReceivedHandler)
            {
                AutoComplete = false,
                MaxConcurrentCalls = 100
            };
            var ruleDescriptions= await subscriptionClient.GetRulesAsync();
            foreach(var ruledesc in ruleDescriptions)
            {
                await subscriptionClient.RemoveRuleAsync(ruledesc.Name);
            }

            // await subscriptionClient.AddRuleAsync(new RuleDescription
            // {
            //     Filter = new TrueFilter() , // FalseFilter()
            //     Name = "BooleanFilter"
            // });

            await subscriptionClient.AddRuleAsync(new RuleDescription
            {
               Filter = new SqlFilter("OrderType='online'"), //Checks the message body and if OrderType property is online it subscribe
               Name = "OnlineOrderSqlRule"
            });

            //await subscriptionClient.AddRuleAsync(new RuleDescription
            //{
            //    Filter=new CorrelationFilter(CorrelationIdToFilter),
            //    Name="CorrelationFilter"
            //});

            subscriptionClient.RegisterMessageHandler(ProcessMessageAsync, messageHandlerOptions);
            Console.WriteLine("Press ENTER to exit, waiting for messages");
            Console.ReadLine();
            subscriptionClient.CloseAsync().Wait();
        }

        private static async Task ProcessMessageAsync(Message message, CancellationToken token)
        {
            Console.WriteLine(Encoding.UTF8.GetString( message.Body));
            await subscriptionClient.CompleteAsync(message.SystemProperties.LockToken);
        }

        private static async Task ExceptionReceivedHandler(ExceptionReceivedEventArgs arg)
        {
            Console.WriteLine(arg.Exception.Message);
            await Task.CompletedTask;
        }
    }
}
