﻿using Microsoft.Azure.ServiceBus;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace TopicOrderPublisher
{
    class Program
    {
        const string ServiceBusConnectionString = "Endpoint=sb://sonusb.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=+p8wA0+QFZnwY/L3v3NGVbZ0sM1SDRpBqAyN3rbVab0=";
        const string TopicName = "orders";
        static ITopicClient topicClient;

        static void Main(string[] args)
        {
            topicClient = new TopicClient(ServiceBusConnectionString, TopicName);
            var orders = new List<Order>
            {
                new Order { Id = 1, ItemName = "Apple", OrderType = "online", Price = 123, Quantity = 10 },
                new Order { Id = 2, ItemName = "Orange", OrderType = "onsite", Price = 60, Quantity = 30},
                new Order { Id = 3, ItemName = "HP Laptop", OrderType = "online", Price = 70000, Quantity = 1 },
                new Order { Id = 4, ItemName = "Mi6", OrderType = "onsite", Price = 21000, Quantity = 2 },
                new Order { Id = 5, ItemName = "Cookies", OrderType = "onsite", Price = 25, Quantity = 3 },
                new Order { Id = 6, ItemName = "Pepsi", OrderType = "online", Price = 50, Quantity = 5 },
                new Order { Id = 7, ItemName = "Burger", OrderType = "online", Price = 120, Quantity = 10 },
                new Order { Id = 8, ItemName = "Vegetables", OrderType = "onsite", Price = 40, Quantity = 1 },
                new Order { Id = 9, ItemName = "Fish", OrderType = "onsite", Price = 200, Quantity = 10 },
                new Order { Id = 10, ItemName = "Mango", OrderType = "online", Price = 90, Quantity = 10 },
            };
            SendMessageAsync(orders).Wait();

            Console.ReadLine();

        }

        private static async Task SendMessageAsync(List<Order> orders)
        {
            try
            {
                var rand = new Random();
                foreach (var item in orders)
                {
                    var data = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(item));
                    var message = new Message(data)
                    {
                        CorrelationId = rand.Next(1,5).ToString(),
                        UserProperties ={
                        { "orderType", item.OrderType },
                        { "quantity", item.Quantity }
                    }
                    };
                    await topicClient.SendAsync(message);
                    Console.WriteLine($"Order placed: {JsonConvert.SerializeObject(item)}, Correlation Id:{message.CorrelationId}");
                }
                await topicClient.CloseAsync();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
