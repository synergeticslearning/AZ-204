
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.IO;

namespace EmployeeSystem.ServiceHelpers
{
    public class StorageHelper
    {
        private BlobServiceClient serviceClient;

        public StorageHelper(IConfiguration configuration)
        {
            var connectionString = configuration.GetConnectionString("StorageConnection");
            serviceClient = new BlobServiceClient(connectionString);
        }

        public async Task<string> CreateContainerAsync(string containerName)
        {
            var metadata = new Dictionary<string, string>()
            {
                { "author", "Sonu Sathyadas" },
                { "application", "Employee System" }
            };
            BlobContainerClient containerClient = serviceClient.GetBlobContainerClient(containerName);
            var blobContainerInfo= await containerClient.CreateIfNotExistsAsync(PublicAccessType.Blob, metadata);
            return blobContainerInfo==null?"Already exists":"Created";
        }

        public async Task<string> UploadFileFromStreamAsync(Stream fileStream, string blobName, string containerName)
        {
            BlobContainerClient containerClient = serviceClient.GetBlobContainerClient(containerName);
            BlobClient blobClient = containerClient.GetBlobClient(blobName);
            await blobClient.UploadAsync(fileStream, overwrite:true);
            fileStream.Close();
            return blobClient.Uri.AbsoluteUri;
        }
    }
}