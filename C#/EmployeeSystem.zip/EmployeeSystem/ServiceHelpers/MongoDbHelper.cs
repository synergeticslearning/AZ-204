using MongoDB.Driver;
using EmployeeSystem.Models;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;

namespace EmployeeSystem.ServiceHelpers
{
    public class MongoDbHelper
    {

        private IMongoClient client;
        private IMongoDatabase database;
        private IMongoCollection<EmployeeMongoModel> items;

        public MongoDbHelper(IConfiguration configuration)
        {
            var connectionString = configuration.GetValue<string>("MongoSettings:ConnectionString");
            var sslEnabled = configuration.GetValue<bool>("MongoSettings:SSLEnabled");
            var databaseName = configuration.GetValue<string>("MongoSettings:Database");
            var collectionName = configuration.GetValue<string>("MongoSettings:Collection");

            var mongoSettings = MongoClientSettings.FromUrl(new MongoUrl(connectionString));
            if (sslEnabled)
            {
                mongoSettings.SslSettings = new SslSettings
                {
                    EnabledSslProtocols = System.Security.Authentication.SslProtocols.Tls12
                };
            }
            this.client = new MongoClient(mongoSettings);
            this.database = client.GetDatabase(databaseName);
            this.items = database.GetCollection<EmployeeMongoModel>(collectionName);
        }
    
        public async Task<EmployeeMongoModel> AddAsync(EmployeeMongoModel item)
        {
            await items.InsertOneAsync(item);
            return item;
        }
    }
}