using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson.Serialization.IdGenerators;

namespace EmployeeSystem.Models
{    
    public class EmployeeMongoModel
    {
        [BsonId(IdGenerator =typeof(StringObjectIdGenerator))]        
        public string Id { get; set; }

        [BsonElement("firstName")]
        public string FirstName { get; set; }

        [BsonElement("lastName")]
        public string LastName { get; set; }

        [BsonElement("email")]
        public string Email { get; set; }

        [BsonElement("salary")]
        public double Salary { get; set; }

        [BsonElement("profileUrl")]
        public string ProfileUrl { get; set; }
    }
}
