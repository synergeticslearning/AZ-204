using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeSystem.Models
{
    public class EmployeeViewModel
    {
        [StringLength(50, ErrorMessage = "Maximum length is 50 characters")]
        [Required(ErrorMessage = "First name cannot be empty")]
        public string FirstName { get; set; }

        [StringLength(50, ErrorMessage = "Maximum length is 50 characters")]
        [Required(ErrorMessage = "Last name cannot be empty")]
        public string LastName { get; set; }

        [DataType(DataType.EmailAddress, ErrorMessage = "Invalid email value")]
        [Required(ErrorMessage = "Email cannot be empty")]
        public string Email { get; set; }

        [DataType(DataType.Currency)]
        [Required(ErrorMessage = "Salary cannot be empty")]
        [Range(1, double.MaxValue, ErrorMessage = "Invalid salary value")]
        public double Salary { get; set; }

        [DataType(DataType.ImageUrl)]
        public IFormFile ProfileUrl { get; set; }

    }
}
