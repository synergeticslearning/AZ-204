using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using EmployeeSystem.Models;
using EmployeeSystem.ServiceHelpers;
using System.IO;

namespace EmployeeSystem.Controllers
{
    public class EmployeeController : Controller
    {

        private StorageHelper storageHelper;
        private MongoDbHelper mongoDbHelper;

        public EmployeeController(StorageHelper storageServcieHelper, MongoDbHelper mongoHelper)
        {
            storageHelper = storageServcieHelper;
            mongoDbHelper = mongoHelper;
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(EmployeeViewModel employee)
        {

            //save employee data to database and upload the profile file to storage account
            await storageHelper.CreateContainerAsync("profiles");
            Stream blobStream = employee.ProfileUrl.OpenReadStream();
            string blobName = employee.ProfileUrl.FileName;
            string blobUri=await storageHelper.UploadFileFromStreamAsync(blobStream, blobName, "profiles");
        
            EmployeeMongoModel emp = new EmployeeMongoModel
            {
                FirstName = employee.FirstName,
                LastName = employee.LastName,
                Email = employee.Email,
                Salary = employee.Salary,
                ProfileUrl = blobUri
            };
            await mongoDbHelper.AddAsync(emp);

            return View();
        }
    }
}