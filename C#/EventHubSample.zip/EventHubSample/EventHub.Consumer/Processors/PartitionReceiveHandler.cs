﻿using EventHub.Common.Models;
using Microsoft.Azure.EventHubs;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EventHub.Consumer.Processors
{
    class PartitionReceiveHandler : IPartitionReceiveHandler
    {
        int maxBatchSize;
        private string partitionId;

        public PartitionReceiveHandler(string partitionId)
        {
            this.partitionId = partitionId;
        }

        public int MaxBatchSize
        {
            get => maxBatchSize;
            set => maxBatchSize = value;
        }

        public Task ProcessErrorAsync(Exception error)
        {
            Console.WriteLine($"Error: {error.Message}");
            return Task.CompletedTask;
        }

        public Task ProcessEventsAsync(IEnumerable<EventData> events)
        {
            foreach (var eventData in events)
            {
                var data = Encoding.UTF8.GetString(eventData.Body.Array, eventData.Body.Offset, eventData.Body.Count);
                var orderDetail = JsonConvert.DeserializeObject<OrderDetail>(data);
                Console.WriteLine("{0,-20} | {1,-12} | {2,-20} | {3,-3}", orderDetail.Id, orderDetail.OrderDate, orderDetail.State, partitionId);
            }
            
            return Task.CompletedTask;
        }
    }
}
