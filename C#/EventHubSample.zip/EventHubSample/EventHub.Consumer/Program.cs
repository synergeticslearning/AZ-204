﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Azure.Storage.Blobs;
using Azure.Messaging.EventHubs;
using Azure.Messaging.EventHubs.Consumer;
using Azure.Messaging.EventHubs.Processor;
using Newtonsoft.Json;
using EventHub.Common.Models;

namespace EventHub.Consumer
{
    public class Program
    {
        private const string connectionString = "Endpoint=sb://sonu-eventhub.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=KGDmCXH/WdyAMad51UGP/d54wU4EfFbmQj3EH19Kf3U=";
        private const string eventHubName = "ordershub";
        private const string blobContainerName = "ordersdata";
        private const string blobStorageConnectionString = "DefaultEndpointsProtocol=https;AccountName=sonustorageaccount;AccountKey=rBN/6zjnOKlcNdRdJaTtUJPpchDZNZXlyFZQ0ScHHAMhX/iDYf7MBvxvSoXXgURJQFmSrwJfdJQWIPXiFjYThg==;EndpointSuffix=core.windows.net";

        static BlobContainerClient storageClient;       
        static EventProcessorClient processor;

        static async Task Main(string[] args)
        {
            string consumerGroup = EventHubConsumerClient.DefaultConsumerGroupName;
            storageClient = new BlobContainerClient(blobStorageConnectionString, blobContainerName);

            processor = new EventProcessorClient(storageClient, consumerGroup, connectionString, eventHubName);

            // Register handlers for processing events and handling errors
            processor.ProcessEventAsync += ProcessEventHandler;
            processor.ProcessErrorAsync += ProcessErrorHandler;

            await processor.StartProcessingAsync();

            // Wait for 30 seconds for the events to be processed
            await Task.Delay(TimeSpan.FromSeconds(30));

            // Stop the processing
            await processor.StopProcessingAsync();

        }

        static async Task ProcessEventHandler(ProcessEventArgs eventArgs)
        {
            var eventData = Encoding.UTF8.GetString(eventArgs.Data.Body.ToArray());
            var orderDetail = JsonConvert.DeserializeObject<OrderDetail>(eventData);
            Console.WriteLine("{0,-10} | {1,-12} | {2,-20} | {3,-5}", orderDetail.Id.Substring(0,5), orderDetail.OrderDate.ToShortDateString(), orderDetail.State, orderDetail.Items.Count);
            // Update checkpoint in the blob storage so that the app receives only new events the next time it's run
            await eventArgs.UpdateCheckpointAsync(eventArgs.CancellationToken);
        }

        static Task ProcessErrorHandler(ProcessErrorEventArgs eventArgs)
        {
            // Write details about the error to the console window
            Console.WriteLine($"\tPartition '{ eventArgs.PartitionId}': an unhandled exception was encountered. This was not expected to happen.");
            Console.WriteLine(eventArgs.Exception.Message);
            return Task.CompletedTask;
        }
    }
}
