﻿using EventHub.Common.Models;
using EventHub.Consumer.Processors;
using Microsoft.Azure.EventHubs;
using Microsoft.Azure.EventHubs.Processor;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EventHub.Consumer
{
    public class Program2
    {
        private const string eventHubConnectionString = "Endpoint=sb://syn-eventhub.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=9M0zjq3hmVLZmA9xqd8t+5R2EZ3byVyPd+/OnlEpYzM=";
        private const string entityPath = "eshopeventhub";
        private const string storageContainerName = "orderinfo";
        private const string storageAccountName = "eshopstorageaccount";
        private const string storageAccountKey = "0K/TA9a6EMAkYg5CzhMHQPyd3TyhWg5OmHNyXDfBu75eel7JoXUD3YQRTr8xQ/KCOloIKV8Ad4mdKzcx0IiXXw==";

        private static readonly string storageConnectionString = string.Format("DefaultEndpointsProtocol=https;AccountName={0};AccountKey={1}", storageAccountName, storageAccountKey);

        static void Main(string[] args)
        {
            MainAsync(args).GetAwaiter().GetResult();
        }

        private static async Task MainAsync(string[] args)
        {
            Console.WriteLine("Registering EventProcessor...");

            var eventProcessorHost = new EventProcessorHost(
                entityPath,
                PartitionReceiver.DefaultConsumerGroupName,
                eventHubConnectionString,
                storageConnectionString,
                storageContainerName);

            // Registers the Event Processor Host and starts receiving messages
            await eventProcessorHost.RegisterEventProcessorAsync<OrderEventProcessor>();

            Console.WriteLine("Receiving. Press ENTER to stop worker.");
            Console.ReadLine();

            // Disposes of the Event Processor Host
            await eventProcessorHost.UnregisterEventProcessorAsync();
        }


    }
}
