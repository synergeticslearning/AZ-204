﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace EventHub.Common.Models
{
    [DataContract]
    public class OrderItem
    {
        [DataMember]
        public string ProductId { get; set; }

        [DataMember]
        public string ProductName { get; set; }

        [DataMember]
        public float UnitPrice { get; set; }

        [DataMember]
        public int Units { get; set; }

        [DataMember]
        public string PictureUrl { get; set; }
    }
}
