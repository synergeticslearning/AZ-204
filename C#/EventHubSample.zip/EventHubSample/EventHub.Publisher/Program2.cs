﻿using System;
using System.Text;
using System.Threading.Tasks;
using EventHub.Publisher.Utils;
using Microsoft.Azure.EventHubs;
using Newtonsoft.Json;

namespace EventHub.Publisher
{
    class Program2
    {
        private static EventHubClient client;
        private const string eventHubConnectionString = "Endpoint=sb://syn-eventhub.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=9M0zjq3hmVLZmA9xqd8t+5R2EZ3byVyPd+/OnlEpYzM=";
        private const string entityPath = "eshopeventhub";

        static void Main(string[] args)
        {
            Console.WriteLine("Press ENTER to start sending events");
            Console.ReadLine();
            MainAsync(args).GetAwaiter().GetResult();
        }

        private static async Task MainAsync(string[] args)
        {

            var connectionStringBuilder = new EventHubsConnectionStringBuilder(eventHubConnectionString)
            {
                EntityPath = entityPath
            };

            client = EventHubClient.CreateFromConnectionString(connectionStringBuilder.ToString());
            await SendMessagesToEventHub(100);
            await client.CloseAsync();
            Console.WriteLine("Press ENTER to exit");
            Console.ReadLine();
        }

        private static async Task SendMessagesToEventHub(int eventCount)
        {
            for (var i = 1; i <= eventCount; i++)
            {
                var order = OrderGenerator.CreateOrder();
                var messageBody = JsonConvert.SerializeObject(order);
                EventData data = new EventData(Encoding.UTF8.GetBytes(messageBody));
                Console.WriteLine("{0,-15} | {1, -20} | {2, -20}", order.Id, order.OrderDate, order.State);
                await client.SendAsync(data);
            }
        }
    }
}
