﻿using System;
using System.Text;
using System.Threading.Tasks;
using Azure.Messaging.EventHubs;
using Azure.Messaging.EventHubs.Producer;
using EventHub.Publisher.Utils;
using Newtonsoft.Json;

namespace EventHub.Publisher
{
    class Program
    {
        private static EventHubProducerClient producerClient;
        private const string connectionString = "Endpoint=sb://sonu-eventhub.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=KGDmCXH/WdyAMad51UGP/d54wU4EfFbmQj3EH19Kf3U=";
        private const string eventHubName = "ordershub";

        static async Task Main(string[] args)
        {
            producerClient = new EventHubProducerClient(connectionString, eventHubName);          
            Console.WriteLine("Press ENTER to start sending events");
            Console.ReadLine();
            await SendMessages(100);
        }

        private static async Task SendMessages(int eventCount)
        {
            using EventDataBatch eventBatch = await producerClient.CreateBatchAsync();
            for (var i = 1; i <= eventCount; i++)
            {
                var order = OrderGenerator.CreateOrder();
                var messageBody = JsonConvert.SerializeObject(order);
                EventData data = new EventData(Encoding.UTF8.GetBytes(messageBody));
                if (!eventBatch.TryAdd(data))
                {
                    // if it is too large for the batch
                    throw new Exception($"Event {i} is too large for the batch and cannot be sent.");
                }                
            }
            try
            {
                // Use the producer client to send the batch of events to the event hub
                await producerClient.SendAsync(eventBatch);
                Console.WriteLine($"A batch of {eventCount} events has been published.");
            }
            finally
            {
                await producerClient.DisposeAsync();
            }
        }
    }
}
