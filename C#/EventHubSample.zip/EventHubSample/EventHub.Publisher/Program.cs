﻿using System;
using System.Text;
using System.Threading.Tasks;
using EventHub.Publisher.Utils;
using Microsoft.Azure.EventHubs;
using Newtonsoft.Json;

namespace EventHub.Publisher
{
    class Program
    {
        private static EventHubClient client;
        private const string eventHubConnectionString = "Endpoint=sb://sonu-hub.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=e1end2SGeO3Oxx8OlgMuJ0iyka/f5+nLZhPLl3T1o2Y=";
        private const string entityPath = "signalshub";

        static void Main(string[] args)
        {
            Console.WriteLine("Press ENTER to start sending events");
            Console.ReadLine();
            MainAsync(args).GetAwaiter().GetResult();
        }

        private static async Task MainAsync(string[] args)
        {
            
            var connectionStringBuilder = new EventHubsConnectionStringBuilder(eventHubConnectionString)
            {
                EntityPath = entityPath
            };

            client = EventHubClient.CreateFromConnectionString(connectionStringBuilder.ToString());
            await SendMessagesToEventHub(100);
            await client.CloseAsync();
            Console.WriteLine("Press ENTER to exit");
            Console.ReadLine();
        }

        private static async Task SendMessagesToEventHub(int eventCount)
        {
            for (var i = 1; i <= eventCount; i++)
            {
                var order = OrderGenerator.CreateOrder();
                var messageBody = JsonConvert.SerializeObject(order);
                EventData data = new EventData(Encoding.UTF8.GetBytes(messageBody));                
                var partitionId = OrderGenerator.GetStateIndex(order.State);
                var partitionSender=client.CreatePartitionSender(partitionId.ToString());
                await partitionSender.SendAsync(data);
                Console.WriteLine("{0,-3} | {1, -20}", partitionId.ToString(), order.State);
            }
        }
    }
}
