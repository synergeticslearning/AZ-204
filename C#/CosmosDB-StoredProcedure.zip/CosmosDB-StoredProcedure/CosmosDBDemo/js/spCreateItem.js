﻿
function addDocument(doc) {
    var collection = getContext().getCollection();

    var isAccepted = collection.createDocument(
        collection.getSelfLink(), doc, function (err, feed, options) {
            if (err) throw err;
            var response = getContext().getResponse();
            response.setBody(feed);
        });

    if (!isAccepted) throw new Error('The query was not accepted by the server.');
}