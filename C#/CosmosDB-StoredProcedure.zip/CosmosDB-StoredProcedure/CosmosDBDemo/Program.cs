﻿using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Cosmos.Scripts;
using System;
using System.IO;

namespace CosmosDBDemo
{
    class Program
    {
        private static string endpoint = "https://sonu-sqldb.documents.azure.com:443/";
        private static string authKey = "04d2Uqq4fgMLDTGXgNXCY51fU5WVlRGCaPom8s8M7rocLtrLpkg8ATkP9gXsuur8GC1dBICSsd1EV0FJ5rZCYQ==";
        private static string database = "sampledb";
        private static string collection = "products";

        static void Main(string[] args)
        {            
            //var procedureBody = File.ReadAllText(@"..\..\..\js\spCreateItem.js");
            //CreateStoredProcedure("spCreateItem", procedureBody);

            Product product = new Product()
            {
                Name = "Kiwi",
                Price = 200,
                Quantity = 40,
                Category = "Fruits"
            };
            ExecuteStoredProcedure("spCreateItem", product);

            Console.ReadLine();
        }

        private static async void CreateStoredProcedure(string procedureId, string procedureBody)
        {
            using (CosmosClient client = new CosmosClient(endpoint, authKey))
            {
                var container= client.GetContainer(database, collection);
                var response = await container.Scripts.CreateStoredProcedureAsync(new StoredProcedureProperties
                {
                    Id =  procedureId,
                    Body = procedureBody
                });
                Console.WriteLine("Stored procedure created");
            }
        }

        private static async void ExecuteStoredProcedure(string procedureId, Product data)
        {
            using (CosmosClient client = new CosmosClient(endpoint, authKey))
            {
                var container = client.GetContainer(database, collection);
                
                dynamic[] newItem = new dynamic[] { data };

                var result = await container.Scripts.ExecuteStoredProcedureAsync<dynamic>(
                    procedureId, new PartitionKey(data.Category), newItem);

                Console.WriteLine(result.Resource);
            }
        }
    }
}
