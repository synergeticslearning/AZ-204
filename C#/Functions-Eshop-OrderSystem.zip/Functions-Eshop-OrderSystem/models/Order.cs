using System;
using Newtonsoft.Json;

namespace az_functions.Models
{
    public class Order{
        [JsonProperty("id")]
        public string Id{get;set;}

        [JsonProperty("orderId")]
        public int OrderId{get;set;}

        [JsonProperty("name")]
        public string Name{get;set;}

        [JsonProperty("amount")]
        public double Amount {get;set;}

        [JsonProperty("mobile")]
        public string Mobile{get;set;}

        [JsonProperty("email")]
        public string Email{get;set;}

        [JsonProperty("orderDate")]
        public DateTime OrderDate{get;set;}

        [JsonProperty("status")]
        public string Status{get;set;}
        
        [JsonProperty("deliveryDate")]
        public DateTime DeliveryDate{get;set;}


    }
}