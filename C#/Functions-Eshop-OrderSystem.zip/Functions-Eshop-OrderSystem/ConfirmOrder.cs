using System;
using az_functions.Models;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
// Deploy using Docker , update dockerfile env variable values
namespace az_functions
{
    public static class ConfirmOrder
    {
        [FunctionName("ConfirmOrder")]
        [return: CosmosDB(databaseName: "shopdb" ,collectionName: "orders",ConnectionStringSetting = "CosmosDBConnection",Id = "{Id}", PartitionKey = "{Email}")]
        public static Order Run([ServiceBusTrigger("orders", Connection = "ServiceBusConnection")]Order orderItem,
        [CosmosDB(databaseName: "shopdb" ,collectionName: "orders",ConnectionStringSetting = "CosmosDBConnection",Id = "{Id}", PartitionKey = "{Email}")]Order orderDoc,
        ILogger log)
        {
            //Check the payment status of the order, if it is completed then update the status of order
            orderDoc.Status="Confirmed";
            orderDoc.DeliveryDate = DateTime.Now.AddDays(5);
            log.LogInformation($"Order confirmed...");
            return orderDoc;
        }
    }
}
