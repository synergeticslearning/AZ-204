using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using az_functions.Models;

namespace az_functions
{
    public static class PlaceOrder
    {
        [FunctionName("PlaceOrder")]
        public static IActionResult Run(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req,
            [CosmosDB(databaseName: "shopdb",collectionName: "orders",ConnectionStringSetting = "CosmosDBConnection")]out dynamic document,
            [ServiceBus("orders", Connection="ServiceBusConnection")] out string queueMessage,
            ILogger log)
        {
            StreamReader sr=new StreamReader(req.Body);
            var order= JsonConvert.DeserializeObject<Order>(sr.ReadToEnd());
            order.Id = Guid.NewGuid().ToString();
            order.Status= "Placed";
            document = order;
            queueMessage = JsonConvert.SerializeObject(order);
            var responseMessage = "Your order processed successfully";
            return new OkObjectResult(responseMessage);
        }
    }
}
